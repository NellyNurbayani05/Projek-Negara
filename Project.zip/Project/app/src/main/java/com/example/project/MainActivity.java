package com.example.project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    SemuaNegaraAdapter adapter;
    ApiInterface anInterface;
    RecyclerView.LayoutManager layoutManager;
    List<Negara> daftarNegara;
    RecyclerView rvNegara;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rvNegara=(RecyclerView) findViewById(R.id.ngr_item);
        layoutManager=new LinearLayoutManager(this);
        rvNegara.setLayoutManager(layoutManager);
        anInterface=ApiClient.ambilNegara().create(ApiInterface.class);
        Call<List<Negara>> listCall = anInterface.getlistNegara();
        listCall.enqueue(new Callback<List<Negara>>() {
            @Override
            public void onResponse(Call<List<Negara>> call, Response<List<Negara>> response) {
                daftarNegara=response.body();
                adapter=new SemuaNegaraAdapter(MainActivity.this,daftarNegara);
                rvNegara.setAdapter(adapter);
            }

            @Override
            public void onFailure(Call<List<Negara>> call, Throwable t) {

            }
        });
    }
}