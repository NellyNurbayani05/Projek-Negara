package com.example.project;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class Negara implements Serializable {
    private Bendera flags;
    private  Logo coatOfArms;
    private String Region;
    private String subregion;
    private Lokasi maps;
    private NamaNegara name;

    public Bendera getFlags() {
        return flags;
    }

    public void setFlags(Bendera flags) {
        this.flags = flags;
    }

    public Logo getCoatOfArms() {
        return coatOfArms;
    }

    public void setCoatOfArms(Logo coatOfArms) {
        this.coatOfArms = coatOfArms;
    }

    public String getRegion() {
        return Region;
    }

    public void setRegion(String region) {
        Region = region;
    }

    public String getSubregion() {
        return subregion;
    }

    public void setSubregion(String subregion) {
        this.subregion = subregion;
    }

    public Lokasi getMaps() {
        return maps;
    }

    public void setMaps(Lokasi maps) {
        this.maps = maps;
    }

    public NamaNegara getName() {
        return name;
    }

    public void setName(NamaNegara name) {
        this.name = name;
    }
}
